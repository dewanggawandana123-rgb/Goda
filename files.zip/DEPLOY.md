# Cara Mengubah Gcollage Jadi Website Sungguhan (Gratis)

Kabar baik: sekarang **cuma ada 1 file** yang perlu diurus — `gcollage.html`. Ikon app dan pengaturan "install app" sudah digabung langsung ke dalam file itu, jadi tidak ada lagi file `manifest.json`, `sw.js`, atau folder `icons` yang berantakan.

> **Catatan kecil:** karena semuanya digabung jadi satu file, fitur "bisa dipakai offline sedikit" (yang sebelumnya diurus oleh `sw.js`) sudah tidak ada lagi — supaya lebih simpel. Semua fitur belajarnya (Vocabulary, Grammar, Mandarin, Quiz, dst.) tetap 100% jalan normal seperti biasa, cuma butuh koneksi internet aktif setiap kali dibuka (wajar, karena memang butuh internet untuk font & beberapa fitur suara).

---

## 📦 Langkah 0 — Ganti Nama File (opsional, tapi disarankan)

Ganti nama `gcollage.html` menjadi **`index.html`** sebelum upload. Alasannya: semua layanan hosting otomatis mencari file bernama `index.html` sebagai halaman utama.

- Kalau **tidak diganti** → link jadi `namamu.vercel.app/gcollage.html` (tetap bisa dipakai, cuma kurang rapi).
- Kalau **diganti jadi `index.html`** → link jadi `namamu.vercel.app` langsung, lebih bersih.

---

## 🚀 Opsi 1 — Netlify Drop (PALING GAMPANG, coba ini dulu)

Tanpa akun, tanpa install apa-apa, langsung jadi dalam hitungan detik.

1. Buka **https://app.netlify.com/drop** di browser laptop/komputer (bukan HP).
2. **Drag & drop file `index.html`** (satu file itu saja) ke tengah halaman itu.
3. Tunggu beberapa detik — langsung muncul link publik, contoh: `https://nama-acak-123.netlify.app`.
4. Selesai. Bagikan link itu ke tim.

**Kekurangan:** kalau upload tanpa akun, site-nya sifatnya "anonim" — kalau mau update lagi nanti, harus drag-drop ulang dan linknya bisa berubah. Kalau mau permanen, klik "Sign up" dulu (masih gratis) sebelum drag-drop.

---

## ▲ Opsi 2 — Vercel (lewat GitHub)

Vercel tidak punya drag-drop langsung dari browser, jadi lewat GitHub dulu (juga gratis, dan enak buat update-update berikutnya).

### A. Buat akun GitHub (kalau belum punya)
Buka **https://github.com/signup**, daftar gratis pakai email.

### B. Upload file ke GitHub

1. Klik ikon **"+"** di pojok kanan atas → **"New repository"**.
2. Ketik nama bebas, misalnya `gcollage-app`. Pilih **Public**. **Jangan** centang "Add a README file". Klik **"Create repository"**.
3. Di halaman repo yang masih kosong, klik link **"uploading an existing file"** di tengah halaman.
4. **Drag file `index.html`** (satu file itu saja) ke kotak putus-putus di browser.
5. Scroll ke bawah, klik tombol hijau **"Commit changes"**.

Selesai — cuma 1 file, jadi jauh lebih cepat dibanding sebelumnya.

**Kalau nanti mau update** (misalnya versi baru dengan lebih banyak kosakata): buka file `index.html` di repo GitHub kamu → klik ikon pensil ✏️ (Edit this file) di kanan atas → hapus semua isinya → tempel isi file baru → klik **"Commit changes"**. Vercel otomatis re-deploy sendiri setelah ini (lihat bagian C).

### C. Hubungkan ke Vercel
1. Buka **https://vercel.com/signup**, klik **"Continue with GitHub"**.
2. Di dashboard Vercel, klik **"Add New..." → "Project"**.
3. Cari repo `gcollage-app`, klik **"Import"**.
4. Biarkan semua setting default, klik **"Deploy"**.
5. Tunggu ±30 detik, dapat link seperti `https://gcollage-app.vercel.app`.

---

## 📄 Opsi 3 — GitHub Pages

Kalau file sudah di GitHub (langkah B di atas), sekalian aktifkan ini tanpa perlu Vercel:

1. Di halaman repo, klik tab **"Settings"** → **"Pages"** (sidebar kiri).
2. Di bagian **Branch**, pilih `main` dan folder `/ (root)` → klik **"Save"**.
3. Tunggu 1-2 menit, refresh — muncul link `https://namauser.github.io/gcollage-app/`.

---

## ❓ Bisa Pakai Wix?

**Bisa, tapi tidak ideal.** Wix bukan tempat untuk upload file HTML mentah — satu-satunya jalan adalah lewat elemen **"Embed a Widget" / "HTML iframe"** (Add (+) → Embed → Embed a Widget), tempel isi `index.html` di sana. Konsekuensinya: Gcollage akan tampil di dalam kotak kecil di tengah halaman Wix (bukan full-screen), dan paket gratis Wix pakai subdomain + watermark. **Tetap lebih disarankan Netlify Drop atau Vercel** di atas — gratis, dan hasilnya lebih rapi.

---

## 📱 Setelah Online — Cara Tim Memakainya

1. Bagikan link ke tim lewat WhatsApp/grup kerja.
2. Sarankan pakai **Chrome**, terutama di Android — fitur rekam suara di Pelafalan, Latihan Kalimat, dan AI Coach paling stabil di Chrome.
3. Di HP, tap menu **⋮ → "Add to Home Screen" / "Install App"** supaya Gcollage muncul sebagai ikon app sendiri.
4. Setiap orang membuat akun sendiri (ID + password + foto) saat pertama kali membuka link — progres belajar tersimpan di browser/perangkat masing-masing, bukan di server pusat.

---

## ⚠️ Batasan yang Perlu Diketahui

Karena Gcollage tetap berupa **file statis** (tanpa server/database di belakangnya):

- ✅ **Bisa**: semua orang buka link yang sama, belajar Vocabulary/Grammar/Mandarin, quiz, lihat progres masing-masing.
- ❌ **Belum bisa**: **Obrolan Tim** dan reaksi di **Leaderboard** tidak tersambung antar HP/laptop berbeda (butuh database asli). **AI Coach** (chat AI sungguhan) hanya jalan selagi dibuka di dalam claude.ai — begitu di-hosting sendiri, itu perlu backend terpisah dengan API key yang disimpan aman di server. Kabari aku kalau nanti mau kejar itu sebagai proyek lanjutan.
